/* JS Snippet to trigger class change on page scroll */
 
(function (element, jQuery) {
    'use strict';
    var target = jQuery(element),
        className = "scrolly",
        scroll,
        mobileBreakpoint = 992;
      
    if(jQuery(window).scrollTop() > 0) {
        target.addClass(className);
    }
      
    jQuery(window).scroll(function(){
           
         scroll = jQuery(window).scrollTop();
    if(scroll > 0 ) {
        target.addClass(className);
    } else {
        target.removeClass(className);
    }
});
}('body',jQuery));